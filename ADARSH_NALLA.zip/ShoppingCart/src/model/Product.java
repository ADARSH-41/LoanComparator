package model;

public class Product {

	private Integer prod_id;
	private String prod_title;
	private Integer prod_prct_id;
	private Integer hsnc_id;
	private String brand;
	private String image;

	public Integer getProd_id() {
		return prod_id;
	}

	public void setProd_id(Integer prod_id) {
		this.prod_id = prod_id;
	}

	public String getProd_title() {
		return prod_title;
	}

	public void setProd_title(String prod_title) {
		this.prod_title = prod_title;
	}

	public Integer getProd_prct_id() {
		return prod_prct_id;
	}

	public void setProd_prct_id(Integer prod_prct_id) {
		this.prod_prct_id = prod_prct_id;
	}

	public Integer getHsnc_id() {
		return hsnc_id;
	}

	public void setHsnc_id(Integer hsnc_id) {
		this.hsnc_id = hsnc_id;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

}
