package models;

import java.util.ArrayList;

public class ProductsList extends ArrayList<Product> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
