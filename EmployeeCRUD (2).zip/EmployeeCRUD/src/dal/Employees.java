package dal;

import java.util.ArrayList;

import model.Employee;

public interface Employees {

	public ArrayList<Employee> getEmployees();
}